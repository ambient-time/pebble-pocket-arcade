# Space Salvage

Five crates, a fragile tug, and a wreck field that grows more dangerous.

## Play

Up/Down turns the tug; Select gives thrust, and holding Select gives a stronger
burst. Or tap a destination and let the tug steer toward it. Pass close to a
crate to attach its tether. Return to the dock at the left to bank it, then
head back for another. Carrying cargo slows the tug.

After banking all five crates, enter the EXIT ring at the upper left. You have
four hull and 150 seconds of active simulation time. A rock collision costs
hull and drops carried cargo; a brief shield prevents repeated damage from the
same impact. More rocks enter as the deadline approaches. Losing all hull or
running out of time ends the mission.

Expect a one-to-two-and-a-half-minute attempt. Docking produces a brief expanding
star distortion; the tether and cargo markings remain visible during flight.

## Pause and resume

Back opens the pause menu: Resume, Restart, How to play, About, and Save and exit.
Restart asks before replacing an unfinished game. On a finished round, press
Select once or tap the outlined replay row to start again. The result explains
the outcome and shows the round totals. The next launch resumes the saved game.
Menus support buttons and touch dragging. Active play saves periodically (about
every ten seconds), at important transitions, and when leaving the app. An
unexpected interruption may lose the last few seconds. Time does not pass while
the app is closed or paused.

About shows Luke Steuber’s portrait and this app’s version. Tap, Select, or
Back returns to the same menu row without advancing the game.

## Readability

The playfield and pieces fill more of the watch. Text uses bold fonts with an
18-pixel minimum; actions and instructions use 24 pixels. Selected controls use
a white fill and black text, and important markers retain outlines or shapes
in addition to color. Touch and button controls are unchanged.

## Screens and shapes

Open space has no horizon, so the whole flight field fits each screen: full
width on rectangles, and on round screens with its corners at the rim. On
144×168 screens the field spans the full width and the bottom line is shorter
("SELECT: thrust", "Return to DOCK", "Fly to EXIT"); the Time Round's top line
drops the word "crates" to fit inside the circle.

On black-and-white Pebbles the closed exit is a dotted ring and the open exit a
solid double ring, rocks are solid with dark pits, crates stay hollow squares,
and the tug stays an outlined triangle. Watches without touch drop the touch
hints.

## Install and build

Open the included `.pbw` with the Pebble phone app and install it on the connected
watch. Version 0.4.0 runs on every Pebble with a native build: Pebble Time 2
(emery), Pebble Round 2 (gabbro), Pebble Time and Time Steel (basalt), Pebble 2
(diorite), Pebble 2 Duo (flint) and Pebble Time Round (chalk). Touch works on
Time 2 and Round 2 with firmware 4.33.2 or later; buttons work everywhere.

The source ZIP is a standalone Pebble project. Extract it, enter its directory,
and run `pebble build` with SDK 4.33.1 and pebble-tool installed. It has no runtime
network service or phone-side JavaScript dependency.

Version 0.4.0. Created by Luke Steuber. MIT license.
Native emulator evidence covers all six targets; physical-watch validation
is still separate. This package does not imply a Pebble Store release.
